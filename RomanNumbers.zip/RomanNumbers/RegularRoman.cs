﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RomanNumbers
{
    public partial class RegularRoman : Form
    {
        public RegularRoman()
        {
            InitializeComponent();
            Roman.Visible = false;
        }



        static string checktxtbox(string s)
        {
            string message = "";
            foreach (char symbol in s)
            {
                if(!char.IsDigit(symbol))
                {
                    message = "Вводить можно только положительные целые числа!";
                }
            }
            return message;
        }
        


        static string checkNumber(int n)
        {
            string message = "";
            if(n < 0 || n > 3999)
            {
                message = "Вводить можно только числа от 0 до 3999!";
            }
            return message;
        }



        static string translateRegular(string s)
        {
            string result = "";
            if (s == "0")
            {
                result = "N";
            }
            else if (s == "1")
            {
                result = "I";
            }
            else if (s == "5")
            {
                result = "V";
            }
            else if (s == "10")
            {
                result = "X";
            }
            else if (s == "50")
            {
                result = "L";
            }
            else if (s == "100")
            {
                result = "C";
            }
            else if (s == "500")
            {
                result = "D";
            }
            else if (s == "1000")
            {
                result = "M";
            }
            else if (s == "3999")
            {
                result = "MMMCMXCIX";
            }
            else
            {
                byte count = 0;
                foreach(char c in s)
                {
                    count++;
                }

                switch(count)
                {
                    case 1:
                        if (s == "0")
                        {
                            result = "N";
                        }
                        else if(s == "2")
                        {
                            result = "II";
                        }
                        else if(s == "3")
                        {
                            result = "III";
                        }
                        else if (s == "4")
                        {
                            result = "IV";
                        }
                        else if (s == "6")
                        {
                            result = "VI";
                        }
                        else if (s == "7")
                        {
                            result = "VII";
                        }
                        else if (s == "8")
                        {
                            result = "VIII";
                        }
                        else if (s == "9")
                        {
                            result = "IX";
                        }
                        break;



                    case 2:
                        //Десятки.
                        if (s[0] == '1')
                        {
                            result = "X";
                        }
                        else if (s[0] == '2')
                        {
                            result = "XX";
                        }
                        else if (s[0] == '3')
                        {
                            result = "XXX";
                        }
                        else if (s[0] == '4')
                        {
                            result = "XL";
                        }
                        else if (s[0] == '5')
                        {
                            result = "L";
                        }
                        else if (s[0] == '6')
                        {
                            result = "LX";
                        }
                        else if (s[0] == '7')
                        {
                            result = "LXX";
                        }
                        else if (s[0] == '8')
                        {
                            result = "LXXX";
                        }
                        else if (s[0] == '9')
                        {
                            result = "XC";
                        }


                        //Единицы.
                        if (s[1] == '1')
                        {
                            result += "I";
                        }
                        else if (s[1] == '2')
                        {
                            result += "II";
                        }
                        else if (s[1] == '3')
                        {
                            result += "III";
                        }
                        else if (s[1] == '4')
                        {
                            result += "IV";
                        }
                        else if (s[1] == '5')
                        {
                            result += "V";
                        }
                        else if (s[1] == '6')
                        {
                            result += "VI";
                        }
                        else if (s[1] == '7')
                        {
                            result += "VII";
                        }
                        else if (s[1] == '8')
                        {
                            result += "VIII";
                        }
                        else if (s[1] == '9')
                        {
                            result += "IX";
                        }
                        break;



                    case 3:
                        //Сотни.
                        if (s[0] == '1')
                        {
                            result += "C";
                        }
                        else if (s[0] == '2')
                        {
                            result += "CC";
                        }
                        else if (s[0] == '3')
                        {
                            result += "CCC";
                        }
                        else if (s[0] == '4')
                        {
                            result += "CD";
                        }
                        else if (s[0] == '5')
                        {
                            result += "D";
                        }
                        else if (s[0] == '6')
                        {
                            result += "DC";
                        }
                        else if (s[0] == '7')
                        {
                            result += "DCC";
                        }
                        else if (s[0] == '8')
                        {
                            result += "DCCC";
                        }
                        else if (s[0] == '9')
                        {
                            result += "CM";
                        }



                        //Десятки.
                        if (s[1] == '0')
                        {
                            result += "N";
                        }
                        else if (s[1] == '1')
                        {
                            result += "X";
                        }
                        else if (s[1] == '2')
                        {
                            result += "XX";
                        }
                        else if (s[1] == '3')
                        {
                            result += "XXX";
                        }
                        else if (s[1] == '4')
                        {
                            result += "XL";
                        }
                        else if (s[1] == '5')
                        {
                            result += "L";
                        }
                        else if (s[1] == '6')
                        {
                            result += "LX";
                        }
                        else if (s[1] == '7')
                        {
                            result += "LXX";
                        }
                        else if (s[1] == '8')
                        {
                            result += "LXXX";
                        }
                        else if (s[1] == '9')
                        {
                            result += "XC";
                        }


                        //Единицы.
                        if (s[2] == '1')
                        {
                            result += "I";
                        }
                        else if (s[2] == '2')
                        {
                            result += "II";
                        }
                        else if (s[2] == '3')
                        {
                            result += "III";
                        }
                        else if (s[2] == '4')
                        {
                            result += "IV";
                        }
                        else if (s[2] == '5')
                        {
                            result += "V";
                        }
                        else if (s[2] == '6')
                        {
                            result += "VI";
                        }
                        else if (s[2] == '7')
                        {
                            result += "VII";
                        }
                        else if (s[2] == '8')
                        {
                            result += "VIII";
                        }
                        else if(s[2] == '9')
                        {
                            result += "IX";
                        }
                        break;


                    case 4:
                        //Тысячи.
                        if (s[0] == '1')
                        {
                            result = "М";
                        }
                        else if (s[0] == '2')
                        {
                            result = "MM";
                        }
                        else
                        {
                            result = "MMM";
                        }



                        //Сотни.
                        if (s[1] == '1')
                        {
                            result += "C";
                        }
                        else if (s[1] == '2')
                        {
                            result += "CC";
                        }
                        else if (s[1] == '3')
                        {
                            result += "CCC";
                        }
                        else if (s[1] == '4')
                        {
                            result += "CD";
                        }
                        else if (s[1] == '5')
                        {
                            result += "D";
                        }
                        else if (s[1] == '6')
                        {
                            result += "DC";
                        }
                        else if (s[1] == '7')
                        {
                            result += "DCC";
                        }
                        else if (s[1] == '8')
                        {
                            result += "DCCC";
                        }
                        else if (s[1] == '9')
                        {
                            result += "CM";
                        }



                        //Десятки.
                        if (s[2] == '0')
                        {
                            result += "N";
                        }
                        else if (s[2] == '1')
                        {
                            result += "X";
                        }
                        else if (s[2] == '2')
                        {
                            result += "XX";
                        }
                        else if (s[2] == '3')
                        {
                            result += "XXX";
                        }
                        else if (s[2] == '4')
                        {
                            result += "XL";
                        }
                        else if (s[2] == '5')
                        {
                            result += "L";
                        }
                        else if (s[2] == '6')
                        {
                            result += "LX";
                        }
                        else if (s[2] == '7')
                        {
                            result += "LXX";
                        }
                        else if (s[2] == '8')
                        {
                            result += "LXXX";
                        }
                        else if (s[2] == '9')
                        {
                            result += "XC";
                        }



                        //Единицы.
                        if (s[3] == '1')
                        {
                            result += "I";
                        }
                        else if (s[3] == '2')
                        {
                            result += "II";
                        }
                        else if (s[3] == '3')
                        {
                            result += "III";
                        }
                        else if (s[3] == '4')
                        {
                            result += "IV";
                        }
                        else if (s[3] == '5')
                        {
                            result += "V";
                        }
                        else if (s[3] == '6')
                        {
                            result += "VI";
                        }
                        else if (s[3] == '7')
                        {
                            result += "VII";
                        }
                        else if (s[3] == '8')
                        {
                            result += "VIII";
                        }
                        else if (s[3] == '9')
                        {
                            result += "IX";
                        }
                        break;



                    default:
                        result = "N";
                        break;
                }
            }
            return result;
        }


        private void Translate_Click(object sender, EventArgs e)
        {
            if (textBoxRegular.Text == "")
            {
                MessageBox.Show("Поле не заполнено.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string number = textBoxRegular.Text;
                string message;
                int n;

                message = checktxtbox(number);

                if (message != "")
                {
                    MessageBox.Show(message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    n = Convert.ToInt32(number);
                    message = checkNumber(n);
                    if (message != "")
                    {
                        MessageBox.Show(message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        Roman.Visible = true;
                        Roman.Text = translateRegular(number);
                    }
                }
            }
        }
    }
}

﻿namespace RomanNumbers
{
    partial class RegularRoman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxRegular = new System.Windows.Forms.TextBox();
            this.Translate = new System.Windows.Forms.Button();
            this.Roman = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxRegular
            // 
            this.textBoxRegular.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxRegular.Location = new System.Drawing.Point(94, 60);
            this.textBoxRegular.Name = "textBoxRegular";
            this.textBoxRegular.Size = new System.Drawing.Size(176, 36);
            this.textBoxRegular.TabIndex = 5;
            // 
            // Translate
            // 
            this.Translate.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Translate.Location = new System.Drawing.Point(94, 102);
            this.Translate.Name = "Translate";
            this.Translate.Size = new System.Drawing.Size(176, 38);
            this.Translate.TabIndex = 3;
            this.Translate.Text = "Перевод";
            this.Translate.UseVisualStyleBackColor = true;
            this.Translate.Click += new System.EventHandler(this.Translate_Click);
            // 
            // Roman
            // 
            this.Roman.AutoSize = true;
            this.Roman.Font = new System.Drawing.Font("Bahnschrift Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Roman.Location = new System.Drawing.Point(94, 22);
            this.Roman.Name = "Roman";
            this.Roman.Size = new System.Drawing.Size(25, 29);
            this.Roman.TabIndex = 6;
            this.Roman.Text = "...";
            // 
            // RegularRoman
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(345, 155);
            this.Controls.Add(this.Roman);
            this.Controls.Add(this.textBoxRegular);
            this.Controls.Add(this.Translate);
            this.Name = "RegularRoman";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Обычное число -> Римское число";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxRegular;
        private System.Windows.Forms.Button Translate;
        private System.Windows.Forms.Label Roman;
    }
}
﻿namespace RomanNumbers
{
    partial class Menu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Choice = new System.Windows.Forms.Button();
            this.Roman = new System.Windows.Forms.RadioButton();
            this.Regular = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // Choice
            // 
            this.Choice.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Choice.Location = new System.Drawing.Point(143, 83);
            this.Choice.Name = "Choice";
            this.Choice.Size = new System.Drawing.Size(159, 40);
            this.Choice.TabIndex = 0;
            this.Choice.Text = "Выбрать";
            this.Choice.UseVisualStyleBackColor = true;
            this.Choice.Click += new System.EventHandler(this.Choice_Click);
            // 
            // Roman
            // 
            this.Roman.AutoSize = true;
            this.Roman.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Roman.Location = new System.Drawing.Point(12, 12);
            this.Roman.Name = "Roman";
            this.Roman.Size = new System.Drawing.Size(404, 33);
            this.Roman.TabIndex = 1;
            this.Roman.TabStop = true;
            this.Roman.Text = "Римские числа -> Обычные числа";
            this.Roman.UseVisualStyleBackColor = true;
            // 
            // Regular
            // 
            this.Regular.AutoSize = true;
            this.Regular.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Regular.Location = new System.Drawing.Point(12, 44);
            this.Regular.Name = "Regular";
            this.Regular.Size = new System.Drawing.Size(404, 33);
            this.Regular.TabIndex = 2;
            this.Regular.TabStop = true;
            this.Regular.Text = "Обычные числа -> Римские числа";
            this.Regular.UseVisualStyleBackColor = true;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 135);
            this.Controls.Add(this.Regular);
            this.Controls.Add(this.Roman);
            this.Controls.Add(this.Choice);
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Меню";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Choice;
        private System.Windows.Forms.RadioButton Roman;
        private System.Windows.Forms.RadioButton Regular;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RomanNumbers
{
    public partial class RomanRegular : Form
    {
        public RomanRegular()
        {
            InitializeComponent();
            Regular.Visible = false;
        }

        static int getArabian(char romanNumber)
        {
            if ('I' == romanNumber) return 1;
            else if ('V' == romanNumber) return 5;
            else if ('X' == romanNumber) return 10;
            else if ('L' == romanNumber) return 50;
            else if ('C' == romanNumber) return 100;
            else if ('D' == romanNumber) return 500;
            else if ('M' == romanNumber) return 1000;
            return 0;
        }

        static int romanToInt(string s)
        {
            int endArray = s.Length - 1;
            char[] charsArray = new char[Convert.ToByte(s.Length)];
            for (int i = 0; i < s.Length; i++)
            {
                charsArray[i] = s[i];
            }

            int arabian;
            int result = getArabian(charsArray[endArray]);

            for (int i = endArray - 1; i >= 0; i--)
            {
                arabian = getArabian(charsArray[i]);

                if (arabian < getArabian(charsArray[i + 1]))
                {
                    result -= arabian;
                }
                else
                {
                    result += arabian;
                }
            }

            return result;
        }

        static bool checkStringOne (string forCheck)
        {
            bool itsok = false;

            foreach (char c in forCheck)
            {
                if (c == 'I' || c == 'V' || c == 'X' || c == 'L' || c == 'C' || c == 'D' || c == 'M')
                {
                    itsok = true;
                }
                else
                {
                    itsok = false;
                    break;
                }
            }

            return itsok;
        }

        static bool checkStringTwo (string forCheck)
        {
            bool itsok;
            int countI = 0, countX = 0, countC = 0, countM = 0;

            foreach (char c in forCheck)
            {
                if (c == 'I') countI++;
                else if (c == 'X') countX++;
                else if (c == 'C') countC++;
                else if (c == 'M') countM++;
            }

            if (countI > 3 || countX > 4 || countC > 3 || countM > 4)
            {
                itsok = false;
            }
            else
            {
                itsok = true;
            }

            return itsok;
        }

        static bool checkCountChars (string s)
        {
            bool itsok = false;

            if (s.Length <= 13)
            {
                itsok = true;
            }

            return itsok;
        }

        private void Translate_Click(object sender, EventArgs e)
        {
            bool itsok;

            itsok = checkCountChars(textBoxRoman.Text);

            if (itsok == true)
            {
                itsok = checkStringOne(textBoxRoman.Text);

                if (itsok == true)
                {
                    itsok = checkStringTwo(textBoxRoman.Text);

                    if (itsok == true)
                    {
                        Regular.Visible = true;
                        Regular.Text = Convert.ToString(romanToInt(textBoxRoman.Text));
                    }
                    else
                    {
                        MessageBox.Show("Превышено допустимое количество повторений из символов: I, V, X, L, C, D, M.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Ввод принимается только из таких символов: I, V, X, L, C, D, M.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Количество символов в вводе не может привышать 13.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
    }
}

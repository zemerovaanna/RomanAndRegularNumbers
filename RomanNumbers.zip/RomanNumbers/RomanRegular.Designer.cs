﻿namespace RomanNumbers
{
    partial class RomanRegular
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Translate = new System.Windows.Forms.Button();
            this.Regular = new System.Windows.Forms.Label();
            this.textBoxRoman = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Translate
            // 
            this.Translate.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Translate.Location = new System.Drawing.Point(48, 101);
            this.Translate.Name = "Translate";
            this.Translate.Size = new System.Drawing.Size(237, 38);
            this.Translate.TabIndex = 0;
            this.Translate.Text = "Перевод";
            this.Translate.UseVisualStyleBackColor = true;
            this.Translate.Click += new System.EventHandler(this.Translate_Click);
            // 
            // Regular
            // 
            this.Regular.AutoSize = true;
            this.Regular.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Regular.Location = new System.Drawing.Point(48, 10);
            this.Regular.Name = "Regular";
            this.Regular.Size = new System.Drawing.Size(28, 29);
            this.Regular.TabIndex = 1;
            this.Regular.Text = "...";
            // 
            // textBoxRoman
            // 
            this.textBoxRoman.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxRoman.Location = new System.Drawing.Point(48, 59);
            this.textBoxRoman.Name = "textBoxRoman";
            this.textBoxRoman.Size = new System.Drawing.Size(237, 36);
            this.textBoxRoman.TabIndex = 2;
            // 
            // RomanRegular
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 153);
            this.Controls.Add(this.textBoxRoman);
            this.Controls.Add(this.Regular);
            this.Controls.Add(this.Translate);
            this.Name = "RomanRegular";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Римское число -> Обычное число";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Translate;
        private System.Windows.Forms.Label Regular;
        private System.Windows.Forms.TextBox textBoxRoman;
    }
}
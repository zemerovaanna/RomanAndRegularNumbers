﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RomanNumbers
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
            Roman.Checked = true;
        }

        private void Choice_Click(object sender, EventArgs e)
        {
            if (Roman.Checked)
            {
                RomanRegular f = new RomanRegular();
                f.ShowDialog();
            }
            else if (Regular.Checked)
            {
                RegularRoman f = new RegularRoman();
                f.ShowDialog();
            }
            else
            {
                MessageBox.Show("Вы не выбрали.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
